import tkinter as tk, sqlite3, os, csv, datetime, matplotlib.pyplot as plt
from tkinter import ttk, messagebox, filedialog
DB = os.path.join(os.path.dirname(__file__), "maharani_demo.db")
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Maharani Official - Demo")
        self.geometry("900x600"); self.configure(bg="#0b0b0b")
        ttk.Style().configure('TLabel', background='#0b0b0b', foreground='white')
        tk.Label(self, text="MAHARANI OFFICIAL", bg="#0b0b0b", fg="#FFD700", font=("Segoe UI",18,"bold")).pack(pady=8)
        nb = ttk.Notebook(self); nb.pack(fill='both', expand=True, padx=8, pady=8)
        pframe = ttk.Frame(nb); nb.add(pframe, text="Products")
        self.ptree = ttk.Treeview(pframe, columns=("SKU","Name","Size","Color","Price","Stock"), show='headings'); self.ptree.pack(fill='both',expand=True)
        for c in self.ptree["columns"]: self.ptree.heading(c,text=c)
        btnf = ttk.Frame(pframe); btnf.pack(fill='x')
        ttk.Button(btnf, text="Refresh", command=self.load_products).pack(side='left', padx=4, pady=4)
        ttk.Button(btnf, text="Export CSV", command=self.export_products).pack(side='left', padx=4)
        self.load_products()
    def load_products(self):
        for i in self.ptree.get_children(): self.ptree.delete(i)
        conn=sqlite3.connect(DB); cur=conn.cursor(); cur.execute("SELECT sku,name,size,color,selling_price,stock_qty FROM products")
        for r in cur.fetchall(): self.ptree.insert("", "end", values=r); conn.close()
    def export_products(self):
        path = filedialog.asksaveasfilename(defaultextension=".csv")
        if not path: return
        conn=sqlite3.connect(DB); cur=conn.cursor(); cur.execute("SELECT sku,name,size,color,selling_price,stock_qty FROM products"); rows=cur.fetchall(); conn.close()
        with open(path,'w',newline='',encoding='utf-8') as f:
            w=csv.writer(f); w.writerow(["SKU","Name","Size","Color","Price","Stock"]); w.writerows(rows)
        messagebox.showinfo("Exported",f"Saved {path}")
if __name__=='__main__':
    import tkinter.ttk as ttk
    App().mainloop()
