
Maharani Official - GitHub Actions Auto-build (Windows .exe)

Contents:
- main.py                 -> Tkinter demo app (GUI)
- maharani_demo.db        -> Sample SQLite DB with products/customers
- requirements.txt
- .github/workflows/build-windows.yml  -> GitHub Actions workflow to build a Windows .exe using PyInstaller

VERY SIMPLE 2 STEPS (I will guide you here):
1) Create a new GitHub repository (https://github.com/new). On the new repo page, drag & drop the ZIP contents or upload the files directly.
   - If you upload a ZIP, extract it into the repo (GitHub web UI allows uploading files).
2) On GitHub, go to the "Actions" tab. Click the workflow named "Build Windows Exe". Click the green "Run workflow" button (choose branch main) and click "Run workflow".
   - Wait 5–10 minutes while GitHub builds. When complete, open the workflow run and download the artifact named "maharani-dist" (it contains the .exe).

If you'd like, I can perform the GitHub upload for you if you provide a temporary repo name or allow me to create a repo. Otherwise these two steps are all you need and I will support every click with exact wording.
